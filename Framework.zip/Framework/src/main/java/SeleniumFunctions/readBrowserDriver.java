package SeleniumFunctions;

public class readBrowserDriver {
	
	public void readbrowser() {
		
	}

}
